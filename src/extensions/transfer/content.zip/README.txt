16-October-2008

Thank you for using Transfer version 1.1

For up to date information on Transfer, you can go to:
http://www.transfer-orm.com

Documentation can be found at:
http://docs.transfer-orm.com

The public Bug Tracker can be found at:
http://tracker.transfer-orm.com

I hope you enjoy using Transfer!

	- Mark Mandel 
	




Copyright 2008, Mark Mandel